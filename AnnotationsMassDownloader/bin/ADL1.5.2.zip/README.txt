Okay so basically I had to rush this program so there may be some bugs (contact me on discord:@Moder112#0247)
A friend of mine realized that annotations are going to die and nobody has made any programs that could preserve them, so I quickly made this on the 9th of January
just put your video and channel links into the txt file and it will automatically download all of the annotations after you run the bat file
make sure to include the full link not just the id, okay?